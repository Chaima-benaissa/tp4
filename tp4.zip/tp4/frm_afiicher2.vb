﻿Public Class frm_afiicher2
    Private Sub frm_afiicher2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        afficher2_livre(djv_livre)
    End Sub

End Class