﻿Public Class liste_des_livres
    Private Sub liste_des_livres_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        afficher_livre(lst_isbn, lst_titre, lst_auteur)


    End Sub
End Class